<?php
//Connect to APEX databse
$connection2 = oci_connect('c3530869@zeus', 'Freddie1234' , 'ZEUS');
?>