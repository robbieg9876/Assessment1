<form method="post" action="./loginsubmit.php" autocomplete="off">
    <label>Email Address: </label>
    <br />
    <input type="text" name="txtEmail" value='' />
    <br />
    <br />
    <label>Password: </label>
    <br />
    <input type="password" name="txtPass" value='' />
    <br />
    <br />
    <input type="submit" name="subLogin" value="Login" class="login2" />
    <br />
    <div class="breakText">New to Leads United?</div>
    <br />
    <a href="register.php" class="reg">Join the club</a>
    <br />
</form>